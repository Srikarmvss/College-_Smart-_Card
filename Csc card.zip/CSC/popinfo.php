<html>
    <head>
    <style>
        body{
        background-image:url('successfullbg.png');
        background-size:100%;
    }
h1 {text-align: center;}

</style>
    </head>
    <body>
        <centre>
            <h1><strong>
                THANK YOU.....</strong>
            </h1>
</centre>
    </body>
</html>