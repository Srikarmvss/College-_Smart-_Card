<!DOCTYPE html>
<html lang="en">
<head>
    <title>Webpage Design</title>
    <link rel="stylesheet" href="home(design).css">
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="menu">
                <ul>
                    <li><a href="home.php" >HOME</a></li>
                    <li><a href="about.html" target="_blank">ABOUT</a></li>
                    <li><a href="cant.html"target="_blank">CANTEEN</a></li>
                    <li><a href="stat.html" target="_blank">STATIONARY</a></li>
                    <li><a href="lib.html" target="_blank">LIBRARY</a></li>
                    <li><a href="index.php" >LOGOUT</a></li>
                    <!--<li><a href="trans(demo).html">TRANSCATION</a></li>-->
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"> <button class="btn">Search</button></a>
                
            </div>

        </div> 
        <div class="content">
            <h1>College <br><span>Smart Card</span> <br></h1>
            <p class="par">The Smart Card would be very instructive in terms of
                following the Employees,Faculty and Students <br> Make your transactions more affordable
                and easily with the smart card  </p>

                <!--<div class="form">
                    <h2>Login Here</h2>
                    <input type="email" name="email" placeholder="Enter Email Here">
                    <input type="password" name="" placeholder="Enter Password Here">
                    <button class="btnn"><a href="#">Login</a></button>

                    <p class="link">Don't have an account<br>
                    <a href="#">Sign up </a> here</a></p>
                    <p class="liw">Log in with</p>

                    <div class="icons">
                        <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-google"></ion-icon></a>
                        <a href="#"><ion-icon name="logo-skype"></ion-icon></a>
                    </div>

                </div>
                    </div>
                </div>-->
        </div>
    </div>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>